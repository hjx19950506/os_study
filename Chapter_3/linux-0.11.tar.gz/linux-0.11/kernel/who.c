#define __LIBRARY__
#include <unistd.h>
#include <errno.h>
#include <asm/segment.h>
#include <linux/kernel.h>
 
char string_buf[64] = {0};
 
int sys_iam(const char * name)
{
    /* just for debug */
    printk("debug: iam is called successfully\n");
    
    int i = 0;
    char char_buf;
 
    while ((char_buf=get_fs_byte(name+i)) != '\0' && i < 63)
    {
        string_buf[i] = char_buf;
        i++;
    }
    string_buf[i] = '\0';
 
    if (i > 23)
    {
        errno = EINVAL;
        return -1;
    }
    else
    {
        return i;
    }
}
 
 
int sys_whoami(char* name, unsigned int size)
{
    int i = 0;
    char char_buf;
 
    while (i < 23)
    {
        char_buf = string_buf[i];
        put_fs_byte(char_buf, name+i);
        i++;
    }
    put_fs_byte('\0', name+i);
 
    if (string_buf[i] != '\0')
    {
        errno = EINVAL;
        return -1;
    }
    else
    {
        return i;
    }
}
